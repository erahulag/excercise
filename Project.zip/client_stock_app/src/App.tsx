import { AppShell, Avatar, Flex, rem, Text } from "@mantine/core";
import { useHeadroom } from "@mantine/hooks";
import "./App.css";
import { Watchlist } from "./components/Watchlist";
import { WebWorkerTester } from "./WebWorker/WebWorkerTester";
import { StoreContextProvider } from "./WebWorker/StoreContextProvider";

function App() {
  const pinned = useHeadroom({ fixedAt: 120 });
  return (<StoreContextProvider>
    <AppShell
      header={{ height: 60, collapsed: !pinned, offset: false }}
      padding="md"
    >
      <AppShell.Header>
        <Flex justify="space-between" align="center" p="0.5rem 1rem">
          <Text size="2rem" fw={700}>
            Watchlist
          </Text>
          <Avatar mt={".25rem"} />
        </Flex>
      </AppShell.Header>

      <AppShell.Main pt={`calc(${rem(60)} + var(--mantine-spacing-md))`}>
        {false && <WebWorkerTester />}
        {<Watchlist name="Testing" symbols={["TSLA", "AAPL", "DE"]} />}
      </AppShell.Main>
    </AppShell>
  </StoreContextProvider>
  );
}

export default App;
