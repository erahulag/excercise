import { observer } from "mobx-react-lite";
import { usePriceStore } from "../WebWorker/StoreContextProvider";

export const PriceTicker: React.FC<{ symbol?: string, price?: number }> =observer( ({ symbol, price=0 }) => {
  const store = usePriceStore()
  const storePrice = store.getPrice(symbol||"TSLA"); // Replace with actual price data
  return (
    <div className="p-4">
      <span> $ {storePrice?.toFixed(2)||   "---"}</span>
    </div>
  );
})
