import { makeAutoObservable } from 'mobx';
import { WorkerAdapter } from './WorkerAdapter';

export class PriceStore {
  prices: Map<string, number> = new Map();
  // workderApi?: Remote<any>;
  workerAdapter?: WorkerAdapter;
  constructor() {
    makeAutoObservable(this);
    this.workerAdapter = new WorkerAdapter(
      this.startListeningPriceUpdates.bind(this)
    );
    this.workerAdapter.connect();
  }

  subscribe(syms: string[]) {
    this.workerAdapter?.subscribe(syms);
  }

  unsubscribe(syms: string[]) {
    this.workerAdapter?.unsubscribe(syms);
  }

  startListeningPriceUpdates(update: any) {
    switch (update?.type) {
      case 'price': { 
        const { symbol, mid } = JSON.parse(update?.data);
        this.setPrice(symbol, mid);
      }
    }
    // WE will add code for disconneciton mesages and other things
  }
  setPrice(symbol: string, price: number) {
    this.prices.set(symbol, price);
  }

    getPrice(symbol: string): number | undefined {
        if (!this.prices.has(symbol)) return undefined;
    return this.prices.get(symbol);
  }

  get symbols(): string[] {
    return Array.from(this.prices.keys());
  }
}

// Singleton instance
// const priceStore = new PriceStore();
export default PriceStore;
