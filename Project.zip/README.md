# WELCOME TO BELVEDERE TRADING WEB DEVELOPMENT CHALLENGE

# Title: Real-Time Stock Price Streaming Application

Problem Statement

You are tasked with building a real-time stock price streaming application that provides users with live updates on stock prices. The application should consist of a React frontend written in Typescript connecting to a backend server through a WebSocket connection. The frontend should display a list of stocks and their corresponding prices, which should update in real-time as new data becomes available.

Requirements

- The React Typescript application should display a list of available stocks (refer to stock_list.json in the backend folder). Users should be able to select which stocks they want to view.
- When a user selects the stock(s) they want to view, the front end should establish a two way WebSocket connection with the backend server to send a subscription request to the backend
- The backend should periodically (per 25ms) update the stock data using the given price simulator, filter it down to the stocks that the client requested and send the updated price(s) back through the same WebSocket connection.
- The frontend should use a web worker to throttle the streaming data from the backend, ensuring that data processing does not block the main thread. The prices being displayed to the user should be updated in a user-friendly manner.
- The frontend should handle any errors or disconnections from the WebSocket connection and provide appropriate feedback to the user
- The backend should be able to handle requests from different clients requesting a different subset of stocks

What's Provided To You

- Boilerplate Code for a React App (bootstrapped with Create React App). Refer to the README.md to read instructions on how to start the client. You are free to choose the WebSocket library and any additional features or improvements that you deem necessary for the application. You are free to choose any styling library you prefer. Please complete the front end part of the challenge in Typescript.
- Boilerplate Code for a Node.js backend with Express. Refer to the README.md to read instructions on how to start the server. (Feel free to use any other framework or language for the backend server if you prefer. Please add necessary instructions to the README.md to run your server)
- Within the backend folder, you will see two files:
	- Stock_List.json: Provides a list of 18 stocks with their initial price.
	- PriceSimulator.ts: Exports a function to generate the price for a given stock symbol. It is initialized with the initial prices from Stock_List.json. Use the generatePrice function in this file to generate a new price for a given stock. If you choose to use a different language, feel free to re-create this function.

Deliverables

- The complete source code of the frontend and backend, including the necessary setup and configuration files.
- Instructions on how to set up and run the application locally

Evaluation Criteria
- Accuracy: The application should meet all the Requirements specified above
- Design: Application should be styled in a user-friendly manner
- Architecture: Application is designed to be scalable and maintain performance, particularly by using web workers and throttling techniques to manage data updates.

BE CREATIVE...
This is a very open-ended task so be creative, show us what you can do, and be prepared to discuss what you did and why.