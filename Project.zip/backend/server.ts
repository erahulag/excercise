import http from 'http';
import { Server } from 'socket.io';
import app from './app';
import { startWebSocketListener } from './live-price-handler/ConnectionReceiver';
// Create HTTP server from Express app
const server = http.createServer(app);

// Initialize Socket.IO
const io = new Server(server, {
    cors: {
        origin: '*',  
    },
});

startWebSocketListener(io);

server.listen(8080, () => {
  console.log("Server listening on port 8080");
});
 
