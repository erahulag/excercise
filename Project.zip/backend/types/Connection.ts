import { PriceMessageType } from "./MessageType";


export interface Connection {
    isSubscribedFor: (symbol: string) => boolean;
    send: (message: PriceMessageType) => void;
}
