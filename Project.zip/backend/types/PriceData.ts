export type PriceData = {
    mid: number;
    symbol: string;
};
