import type { Socket } from 'socket.io';
import { Connection } from '../types/Connection';
import { PriceMessageType, ReqMessageType } from '../types/MessageType';
import { ACK, MessageName, REPLACE_SUBS, SUBS_PRICE, UNSUBS_PRICE } from '../types/RequestMessageName';
import { removeFromPool } from './ClientManager';

/**
 * 
 
 
 */

export class ClientConnection implements Connection {
    symbols = new Set<string>();
    constructor(readonly socket: Socket) {
        console.log(`🟢 Client connected: ${socket.id}`);
        this.start();
    }

    isSubscribedFor(sym: string) {
        return this.symbols.has(sym);
    }

    send(message: PriceMessageType) {
        if (message?.data?.mid !== undefined) {
            this.dispatch(message.name, message.data);
        }
    }

    dispatch(msg: MessageName | 'ack', data: Record<string, any>) {
        this.socket.emit(msg, JSON.stringify(data));
    }

    greet() {
        this.dispatch('ack', { status: 'OK' });
    }

    handleMessageRequest(msg: ReqMessageType) {
        console.log('Client req rcvs', typeof msg, msg?.type, msg?.syms);
        const payload = msg;
        //const payload: {type?:string,syms?:any[], reqID?:string} = {}
        switch (payload?.type) {
            case SUBS_PRICE:
                payload?.syms?.forEach((sym) => this.symbols.add(sym));
                this.dispatch(ACK, { status: 'OK', reqID: payload?.reqID });
                break;
            case UNSUBS_PRICE:
                payload?.syms?.forEach((sym) => this.symbols.delete(sym));
                this.dispatch(ACK, { status: 'OK', reqID: payload?.reqID });
                break;
            case REPLACE_SUBS:
                this.symbols.clear();
                payload?.syms?.forEach((sym) => this.symbols.add(sym));
                this.dispatch(ACK, { status: 'OK', reqID: payload?.reqID });
                break;
            default:
                this.dispatch(ACK, { status: 'ERROR', msg });
        }
    }

    terminate() {
        removeFromPool(this);
        console.log(`🔴 Client disconnected: ${this.socket.id}`);
    }

    start() {
        this.socket.on('request', this.handleMessageRequest.bind(this));
        this.socket.on('disconnect', this.terminate.bind(this));
    }
}