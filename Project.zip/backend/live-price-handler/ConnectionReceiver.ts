import type { Server, Socket } from 'socket.io';
import generatePrice from '../PriceSimulator';
import Stock_List from "../stock_list.json";
import { PriceData } from '../types/PriceData';
import { PRICE } from '../types/RequestMessageName';
import { ClientConnection } from './ClientConnection';
import { addToPool, poolSize, publishUpdateToConnections } from './ClientManager';

export const SocketConnectionHandler = (socket: Socket) => {
    try {
        addToPool(new ClientConnection(socket));
        console.log(`Added new client connection: (current size: ', ${poolSize()})`);
    } catch (e) {
        console.error(`Not able to add client connection : SocketID: ${socket?.id}`);
    }
};

export const startWebSocketListener = (io: Server) => {
    try {
        console.log('Starting WebSocket listener...');
        // Socket.IO logic
        io.on('connection', SocketConnectionHandler);
        setTimeout(() => {
            startPriceGenerator();
        }, 1);
    } catch (e) {
        console.error('Error setting up Socket.IO connection:', e);
        // TODO: May need to terminate the server??
    }
};

export const startPriceGenerator = () => {
    const symbols = Object.keys(Stock_List);
    console.log('Starting price generator...');
    setInterval(() => {
        symbols.forEach((symbol) => {
            const mid = generatePrice(symbol);
           // console.debug(`Generating price for ${symbol} : ${mid}`);
            dispatchPriceUpdatesToClients({ symbol, mid });
        });
    }, 100);
}

export const dispatchPriceUpdatesToClients = (msg:PriceData) => {
    publishUpdateToConnections(PRICE, {
        symbol: msg.symbol,
        mid: msg.mid,
    });
};
