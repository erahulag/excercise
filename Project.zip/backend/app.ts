import cors from 'cors'; // Import CORS
import express from 'express';
import symbolRoutes from "./routes/symbols";

const app = express();

app.use(cors()); // Enable CORS
app.use(express.json()); // parse JSON request bodies
app.use('/symbols', symbolRoutes);
// app.use('/symbols', routes);

export default app;
