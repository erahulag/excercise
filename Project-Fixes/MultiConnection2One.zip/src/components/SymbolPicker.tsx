import { Select } from "@mantine/core";
import axios from "axios";
import React, { useEffect, useState } from "react";

export interface SymbolInfo {
  symbol: string;
}

export const SymbolPicker: React.FC<{
  onSelect?: (v?: string | null) => void;
}> = ({ onSelect }) => {
  const selectionHandler = (value?: string | null) => {
    onSelect?.(value);
  };
  const [data, setData] = useState<string[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      const resp = await axios.get("http://localhost:8080/symbols/all");
      const d = resp.data?.map((d: any) => d?.symbol);
      setData(d);
    };
    fetchData();
  }, [setData]);

  return (
    <>
      <Select
        placeholder="e.g. TSLA"
        data={data}
        defaultValue="React"
        onChange={selectionHandler}
        clearable
        searchable
        mt="md"
      />
    </>
  );
};
