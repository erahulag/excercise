import { ActionIcon, Card, Flex, Group, Menu, Text } from "@mantine/core";
import { IconDots, IconEye, IconFileZip, IconTrash } from "@tabler/icons-react";
import { observer } from "mobx-react-lite";
import { useEffect, useState } from "react";
import { usePriceStore } from "../WebWorker/StoreContextProvider";
import { SymbolPicker } from "./SymbolPicker";
import WatchlistItem from "./WatchlistItem";

// https://mantine.dev/core/card/

export interface WatchlistCardProps {
  name?: string;
  symbols?: string[];
}

export const Watchlist: React.FC<WatchlistCardProps> = observer(({ name }) => {
  const store = usePriceStore();
  const [symbols, setSymbols] = useState<string[]>(["TSLA"]);

  useEffect(() => {
    store.subscribe(symbols);
  }, [symbols, store]);

  const onAddNewSecurity = (sym?: string | null) => {
    if (sym && !symbols.includes(sym)) {
      setSymbols((prev) => [sym, ...prev]);
    }
  };

  return (
    <Card
      withBorder
      shadow="sm"
      radius="md"
      styles={{ root: { width: 350, height: "100%" } }}
    >
      <Card.Section withBorder inheritPadding py="xs">
        <Group justify="space-between">
          <Text fw={500}>{name}</Text>
          <Menu withinPortal position="bottom-end" shadow="sm">
            <Menu.Target>
              <ActionIcon variant="subtle" color="gray">
                <IconDots size={16} />
              </ActionIcon>
            </Menu.Target>

            <Menu.Dropdown>
              <Menu.Item leftSection={<IconFileZip size={14} />}>
                Sort asc by name
              </Menu.Item>
              <Menu.Item leftSection={<IconEye size={14} />}>
                Sort desc by name
              </Menu.Item>
              <Menu.Item leftSection={<IconTrash size={14} />} color="red">
                Delete
              </Menu.Item>
            </Menu.Dropdown>
          </Menu>
        </Group>
      </Card.Section>
      <Card.Section inheritPadding mt="0px" pb="md">
        <SymbolPicker onSelect={onAddNewSecurity} />
      </Card.Section>
      <Card.Section inheritPadding mt="sm" pb="md">
        <Flex direction={"column"} gap={"sm"}>
          {symbols?.map((symbol) => (
            <WatchlistItem key={symbol} symbol={symbol} />
          ))}
        </Flex>
      </Card.Section>
    </Card>
  );
});
