import { AckMessageType } from "../model/MessageType";
import { PriceData } from "../model/PriceData";
import { WBRequestMessageName } from "../model/WebWorkerEvent";

export class WorkerAdapter {
  private worker: Worker;

  constructor(readonly onMessage: (e: PriceData | AckMessageType) => void) {
    this.worker = new Worker(
      new URL("../price-web-worker.ts", import.meta.url),
    );
    this.subscribeWBmessages();
  }

  subscribeWBmessages() {
    if (this.worker) {
      this.worker.onmessage = (e: MessageEvent<PriceData | AckMessageType>) => {
        console.log("Data sent from web workd", e);
        this.onMessage?.(e.data);
      };
    }
  }

  connect(): void {
    this.worker.postMessage({
      type: WBRequestMessageName.CONNECT,
      payload: {},
    });
  }
  subscribe(symbols: string[]): void {
    this.worker.postMessage({
      type: WBRequestMessageName.SUBSCRIBE,
      payload: { symbols },
    });
  }
  unsubscribe(symbols: string[]): void {
    this.worker.postMessage({
      type: WBRequestMessageName.UNSUBSCRIBE,
      payload: { symbols },
    });
  }
  disconnect(): void {
    this.worker.postMessage({
      type: WBRequestMessageName.DISCONNECT,
      payload: {},
    });
  }
  replace(symbols: string[]): void {
    this.worker.postMessage({
      type: WBRequestMessageName.REPLACE,
      payload: { symbols },
    });
  }
  public postMessage(message: any): void {
    this.worker.postMessage(message);
  }

  public terminate(): void {
    this.disconnect();
    this.worker.terminate();
  }
}
