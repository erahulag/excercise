import { createContext, useContext, useState } from "react";
import { PriceStore } from "./PriceStore";

// Create a context for the price store
const PriceStoreContext = createContext<PriceStore | null>(null);

export const StoreContextProvider: React.FC<{ children: any }> = ({
  children,
}) => {
  // Initialize the price store state
  const [priceStore, setPriceStore] = useState<PriceStore|null>(()=>PriceStore.instantiate());
  

  return (
    <PriceStoreContext.Provider value={priceStore}>
      {children}
    </PriceStoreContext.Provider>
  );
};

// Custom hook to use the price store context
export const usePriceStore = () => {
  const context = useContext(PriceStoreContext);
  if (!context) {
    throw new Error("usePriceStore must be used within a StoreContextProvider");
  }
  return context;
};
