export enum WBRequestMessageName {
  CONNECT = "connect",
  SUBSCRIBE = "subscribe",
  UNSUBSCRIBE = "unsubscribe",
  DISCONNECT = "disconnect",
  REPLACE = "replace",
}

export interface WBPayload {
  url?: string;
  symbols?: string[];
}

export interface WbRequestMessage {
  type: WBRequestMessageName;
  payload: WBPayload;
}
