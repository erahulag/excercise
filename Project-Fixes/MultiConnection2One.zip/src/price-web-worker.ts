import { WbRequestMessage, WBRequestMessageName } from "./model/WebWorkerEvent";
import { SubscriptionManager } from "./WebWorker/SubscriptionManager";

let subscriptionManager: SubscriptionManager | null = null;
if (!subscriptionManager) {
  subscriptionManager = new SubscriptionManager();
}

if (subscriptionManager) {
  subscriptionManager.setupConnectionUpdateHandler((connected) => {
    postMessage({
      connected,
      type: "connection",
    });
  });

  subscriptionManager.setupAckUpdateHandler((data) => {
    postMessage({
      data,
      type: "ack",
    });
  });

  subscriptionManager.setupPriceUpdateHandler((data) => {
    postMessage({
      data,
      type: "price",
    });
  });
}

onmessage = function (e: MessageEvent<WbRequestMessage>) {
  const { type, payload } = e.data;
  if (!subscriptionManager) {
    subscriptionManager = new SubscriptionManager();
  }
  switch (type) {
    case WBRequestMessageName.CONNECT:
      console.log("Connecting to server at:", payload.url);
      subscriptionManager.connect();
      break;
    case WBRequestMessageName.SUBSCRIBE:
      console.log("Subscribing to symbols:", payload.symbols);
      subscriptionManager.subscribe(payload.symbols || []);
      break;
    case WBRequestMessageName.UNSUBSCRIBE:
      console.log("Unsubscribing from symbols:", payload.symbols);
      subscriptionManager.unsubscribe(payload.symbols || []);
      break;
    case WBRequestMessageName.DISCONNECT:
      console.log("Disconnecting from server");
      subscriptionManager.disconnect();
      break;
    case WBRequestMessageName.REPLACE:
      console.log("Replacing the worker", "DONOTHING");
      break;
    default:
      console.error("Unknown message type:", type, e.data, payload);
  }
};
