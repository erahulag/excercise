import { Connection } from "../types/Connection";
import { PriceData } from "../types/PriceData";
import { ResponseMessageName } from "../types/RequestMessageName";
 
// can add a singleton patter
const ConnectionPool: Set<Connection> = new Set();
export function addToPool(conn: Connection) {
    if (ConnectionPool.has(conn)) {
        console.warn('Why are we need to add same connection again?');
    }
    ConnectionPool.add(conn);
}

export function removeFromPool(conn: Connection) {
    if (!ConnectionPool.has(conn)) {
        console.warn('Why are we need to add same connection again?');
    }
    ConnectionPool.delete(conn);
}

export function poolSize() {
    return ConnectionPool.size;
}

export function publishUpdateToConnections(
    msgname: ResponseMessageName,
    msg: PriceData ,
) {
    for (const conn of [...ConnectionPool]) {
        if (conn.isSubscribedFor(msg.symbol)) {
            conn.send({
                name: msgname,
                data: msg,
            });
        }
    }
}
