import { Router } from 'express';
import { all, details, search } from '../data/symbols';

const router = Router();

router.get('/search', (req, res) => {
    const { query } = req;
    const text = String(query?.q || '');
    res.json(search(text));
});

router.get('/details', (req, res) => {
    const { query } = req;

    const ids = (query?.ids || []) as string[];
    res.json(details(ids));
});
router.get('/all', (req, res) => { 
    res.json(all());
});
export default router;
