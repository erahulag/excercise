export interface Security { 
    symbol: string; 
    sector?: string;
    inPosition?: boolean;
}
