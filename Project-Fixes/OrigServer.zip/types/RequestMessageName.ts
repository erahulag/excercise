export const ACK="ack"
export const PRICE = "price"

export type ResponseMessageName = 'price' | 'ack';

export const SUBS_PRICE = 'subscribe-price';
export const UNSUBS_PRICE = 'unsubscribe-price';    
export const REPLACE_SUBS = 'replace-price-subscription';


export type RequestMessageName = 'subscribe-price' |
    'unsubscribe-price' |
    'replace-price-subscription';

export type MessageName = ResponseMessageName | RequestMessageName;  // | 'error' | 'info' | 'warning' | 'success';  // Add other message types as needed