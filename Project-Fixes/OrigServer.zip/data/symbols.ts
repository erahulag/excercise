import stocks from '../stock_list.json';
import { Security } from '../types/Security';

const securities: Security[] = Object.entries(stocks).map(
  ([symbol, closePx]) => ({
    symbol: symbol.toUpperCase(),
    inPosition: closePx < 100,
  })
);

export function search(text: string) {
  if (!text) return [];
  const txt = text.toUpperCase();
  return securities.filter((sec) => {
    return sec.symbol.includes(txt);
  });
}

export function details(ids: Array<string | number>) {
  return securities.filter((sec) => ids.includes(sec.symbol));
}

export function all( ) {
  return securities ;
}
