import { Card, Flex, Text } from "@mantine/core";
import { PureComponent, type CSSProperties } from "react";
import { PriceTicker } from "./PriceTicker";

class WatchlistItem extends PureComponent<{
  data?: Array<{ symbol: string }>;
  index?: number;
  symbol?: string;
  style?: CSSProperties;
  price?: number
}> {
  render() {
    const { data, index = 0, style, symbol , price} = this.props;
    const sym = data?.[index]?.symbol ?? "TSLA";
    return (
      <div style={style}>
        <Card
          withBorder
          shadow="sm"
          radius="md"
          styles={{ root: { height: "100%" } }}
        >
          <Flex direction={"column"} justify={"center"} h={"100%"}>
            <Flex justify={"space-between"} align={"center"} flex="1">
              <div>
                <Flex direction={"column"}>
                  <Text size="lg" fw={700}>
                    {symbol || sym}
                  </Text>
                </Flex>
              </div>
              <div></div>
              <div>
                <PriceTicker symbol={symbol} price={price} />
              </div>
            </Flex>
          </Flex>
        </Card>
      </div>
    );
  }
}

export default WatchlistItem;
