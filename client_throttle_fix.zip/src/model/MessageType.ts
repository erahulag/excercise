import { PriceData } from "./PriceData";
import { RequestMessageName, ResponseMessageName } from "./RequestMessageName";

export interface PriceMessageType {
  name: ResponseMessageName;
  data: PriceData;
}

export interface AckMessageType {
  status: "ERROR" | "OK";
  msg?: string;
  reqID?: string;
}

export interface ReqMessageType {
  type: RequestMessageName;
  syms: string[];
  reqID: string;
}
