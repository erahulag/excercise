import { Button, Flex, Paper, Text } from "@mantine/core";
import { useEffect, useRef, useState } from "react";
import { WorkerAdapter } from "./WorkerAdapter";

export const WebWorkerTester = () => {
  const workerRef = useRef<WorkerAdapter | null>(null);
  const [messages, setMessages] = useState<string[]>([]);

  useEffect(() => {
    workerRef.current = new WorkerAdapter((data) => {
      setMessages((prev) => [...prev, `  ${JSON.stringify(data)}`]);
    });

    return () => {
      try {
        if (workerRef.current) {
          workerRef.current.terminate();
        }
      } catch (e) {
        console.error(e);
      }
    };
  }, []);

  return (
    <Flex direction={"column"} gap={10}>
      <Flex direction={"row"} gap={10}>
        <Button
          onClick={() => {
            workerRef.current?.connect();
          }}
        >
          CONNECT
        </Button>

        <Button onClick={() => workerRef.current?.subscribe(["TSLA", "AAPL"])}>
          Subscribe TSLA, AAPL
        </Button>
        <Button onClick={() => workerRef.current?.unsubscribe(["AAPL"])}>
          Unsubscribe AAPL
        </Button>
        <Button
          onClick={() => {
            workerRef.current?.disconnect();
          }}
        >
          DISCONNECT
        </Button>
      </Flex>
      <Paper withBorder styles={{ root: { minHeight: 100, width: "100vw" } }}>
        {messages?.map((m, idx) => <Text key={idx}>{m}</Text>)}
      </Paper>
    </Flex>
  );
};
