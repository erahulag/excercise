import { GroupedObservable, Subject } from 'rxjs';
import { auditTime, groupBy, map, mergeMap } from 'rxjs/operators';
import { type Socket, io } from 'socket.io-client';
import { AckMessageType, ReqMessageType } from '../model/MessageType';
import { PriceData } from '../model/PriceData';

import {
  ACK,
  PRICE,
  REQUEST,
  SUBS_PRICE,
  UNSUBS_PRICE,
} from '../model/RequestMessageName';

class SubscriptionManager {
  socket?: Socket;
  priceUpdateHandler?: (data: PriceData) => void;
  ackUpdateHandler?: (data: AckMessageType) => void;
  connectionStatusHandler?: (connected: boolean) => void;
  throttle = 1250;
  priceStream = new Subject<PriceData>();
  constructor() {
    this.socket = io('http://localhost:8080', {
      autoConnect: false,
      transports: ['websocket'],
    });

    this.startListening();
    this.setupToSendPriceUpdates();
  }
  setupToSendPriceUpdates() {
    if (this.priceStream) {
      this.priceStream
        .pipe(
          groupBy((update) => update.symbol),
          mergeMap((group$: GroupedObservable<string, PriceData>) =>
            group$.pipe(
              auditTime(this.throttle), // 1 update/sec per symbol
              map(
                (update: PriceData) =>
                  ({
                    symbol: group$.key,
                    mid: update.mid,
                  } as PriceData)
              )
            )
          )
        )
        .subscribe((data: PriceData) => {
          console.log(data)
          this.priceUpdateHandler?.(data);
        });
    }
  }

  onConnect() {
    console.log('Connected to server');
    this.connectionStatusHandler?.(true);
  }
  onDisconnect() {
    console.log('Disconnected from server');
    this.connectionStatusHandler?.(false);
  }
  onPriceUPdate(data: string) {
    console.log('Price data received:', data);
    this.priceStream.next(JSON.parse(data) as PriceData);
    
   //  this.priceUpdateHandler?.(data);
  }
  onAck(data: AckMessageType) {
    console.log('Ack data received:', data);
    this.ackUpdateHandler?.(data);
  }
  setupPriceUpdateHandler(cb: (data: PriceData) => void) {
    if (!cb) {
      console.log('Invaild.');
    } else {
      this.priceUpdateHandler = cb;
    }
  }

  setupConnectionUpdateHandler(cb: (connected: boolean) => void) {
    if (!cb) {
      console.log('Invalid');
    } else {
      this.connectionStatusHandler = cb;
    }
  }

  setupAckUpdateHandler(cb: (data: AckMessageType) => void) {
    if (!cb) {
      console.log('Invalid');
    } else {
      this.ackUpdateHandler = cb;
    }
  }

  startListening() {
    this.socket?.on('connected', this.onConnect.bind(this));
    this.socket?.on('disconnect', this.onDisconnect.bind(this));
    this.socket?.on(PRICE, this.onPriceUPdate.bind(this));
    this.socket?.on(ACK, this.onAck.bind(this));
  }
  subscribe(symbols: string[]) {
    if (symbols?.length) {
      console.log('SUBS:sent', symbols);
      this.socket?.emit(REQUEST, {
        reqID: '1',
        syms: symbols,
        type: SUBS_PRICE,
      } as ReqMessageType);
    } else {
      console.log('SUBS: No symbols provided');
    }
  }
  unsubscribe(symbols: string[]) {
    if (symbols?.length) {
      this.socket?.emit(REQUEST, {
        reqID: '1',
        syms: symbols,
        type: UNSUBS_PRICE,
      } as ReqMessageType);
    } else {
      console.log('UBSUB: No symbols provided');
    }
  }

  connect() {
    if(!this.socket?.connected){
      this.socket?.connect();
    }
  }
  disconnect() {
    this.socket?.disconnect();
  }
}

export const subscriptionManager = new SubscriptionManager();
